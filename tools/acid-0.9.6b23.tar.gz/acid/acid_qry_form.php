<?php
/*  
 * Analysis Console for Intrusion Databases (ACID)
 *
 * Author: Roman Danyliw <rdd@cert.org>, <roman@danyliw.com>
 *
 * Copyright (C) 2000, 2001, 2002 Carnegie Mellon University
 * (see the file 'acid_main.php' for license details)
 *
 * Purpose: renders the HTML form to gather search criteria
 *
 */

if ( $submit == "TCP" )        {  $cs->criteria['layer4']->Set("TCP");   }
if ( $submit == "UDP" )        {  $cs->criteria['layer4']->Set("UDP");   }
if ( $submit == "ICMP" )       {  $cs->criteria['layer4']->Set("ICMP");  }
if ( $submit == "no layer4" )  {  $cs->criteria['layer4']->Set("");      }

if ( $submit == "ADD Time" && $cs->criteria['time']->GetFormItemCnt() < $MAX_ROWS)         
   $cs->criteria['time']->AddFormItem($submit, $cs->criteria['layer4']->Get());
if ( $submit == "ADD Addr" && $cs->criteria['ip_addr']->GetFormItemCnt() < $MAX_ROWS)     
   $cs->criteria['ip_addr']->AddFormItem($submit, $cs->criteria['layer4']->Get());
if ( $submit == "ADD IP Field" && $cs->criteria['ip_field']->GetFormItemCnt() < $MAX_ROWS)    
   $cs->criteria['ip_field']->AddFormItem($submit, $cs->criteria['layer4']->Get());
/*if ( $submit == "ADD IP Option Field"  && $ip_opt_cnt < $MAX_ROWS)      
{  $submit = $layer4;  $ip_opt_cnt++;     }*/
if ( $submit == "ADD TCP Port" && $cs->criteria['tcp_port']->GetFormItemCnt() < $MAX_ROWS)    
   $cs->criteria['tcp_port']->AddFormItem($submit, $cs->criteria['layer4']->Get());
if ( $submit == "ADD TCP Field" && $cs->criteria['tcp_field']->GetFormItemCnt() < $MAX_ROWS)   
   $cs->criteria['tcp_field']->AddFormItem($submit, $cs->criteria['layer4']->Get());
/*if ( $submit == "ADD TCP Option Field" && $tcp_opt_cnt < $MAX_ROWS)     
{  $submit = $layer4;  $tcp_opt_cnt++;    } */
if ( $submit == "ADD UDP Port" && $cs->criteria['udp_port']->GetFormItemCnt() < $MAX_ROWS)    
   $cs->criteria['udp_port']->AddFormItem($submit, $cs->criteria['layer4']->Get());
if ( $submit == "ADD UDP Field" && $cs->criteria['udp_field']->GetFormItemCnt() < $MAX_ROWS)
   $cs->criteria['udp_field']->AddFormItem($submit, $cs->criteria['layer4']->Get());
if ( $submit == "ADD ICMP Field" && $cs->criteria['icmp_field']->GetFormItemCnt() < $MAX_ROWS)
   $cs->criteria['icmp_field']->AddFormItem($submit, $cs->criteria['layer4']->Get());
if ( $submit == "ADD Payload" && $cs->criteria['data']->GetFormItemCnt() < $MAX_ROWS)
   $cs->criteria['data']->AddFormItem($submit, $cs->criteria['layer4']->Get());

echo '
<!-- ************ Meta Criteria ******************** -->
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="metatitle"><B><FONT COLOR="#FFFFFF">Meta Criteria</FONT></B></TD>
      <TD></TD></TR>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">
  <TR>
      <TD COLSPAN=2>
           <B>Sensor: </B>';
     $cs->criteria['sensor']->PrintForm();

     echo '<B>Alert Group: </B>';
     $cs->criteria['ag']->PrintForm();
     echo '</TD>';

     echo '<TR>
            <TD><B>Signature: </B></TD>
           <TD>';  

     $cs->criteria['sig']->PrintForm();

     if ( $db->acidGetDBVersion() >= 103 )
     {
        echo '<B>Classification: </B>';
        $cs->criteria['sig_class']->PrintForm();
        echo '<B>Priority: </B>';
        $cs->criteria['sig_priority']->PrintForm();
     }     

     echo '</TD></TR>';    

echo '<TR>
      <TD><B>Alert Time:</B></TD>
      <TD>';
      $cs->criteria['time']->PrintForm();    
      
        echo '
</TABLE>';

  echo '
<!-- ************ IP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="iptitle"><B>IP Criteria</B></TD>
      <TD></TD></TR>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';
      echo '<TR><TD VALIGN=TOP><B>Address:</B>';  
      echo '    <TD>';

      $cs->criteria['ip_addr']->PrintForm();

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';

      $cs->criteria['ip_field']->PrintForm();

/*      echo '<TR><TD><B>Option:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $ip_opt_cnt; $i++ )
  {
      echo '    <SELECT NAME="ip_opt['.$i.'][0]"><OPTION VALUE=" " '.chk_select($ip_opt[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($ip_opt[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="ip_opt['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($ip_opt[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="opt_code" '.chk_select($ip_opt[$i][1],"opt_code").'>code';
      echo '                                       <OPTION VALUE="opt_len" '.chk_select($ip_opt[$i][1],"opt_len").'>length</SELECT>';
      echo '    <SELECT NAME="ip_opt['.$i.'][2]"><OPTION VALUE="="  '.chk_select($ip_opt[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($ip_opt[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($ip_opt[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($ip_opt[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($ip_opt[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($ip_opt[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="ip_opt['.$i.'][3]" SIZE=5 VALUE="'.$ip_opt[$i][3].'">';
      echo '    <SELECT NAME="ip_opt['.$i.'][4]"><OPTION VALUE=" " '.chk_select($ip_opt[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($ip_opt[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($ip_opt[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="ip_opt['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($ip_opt[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($ip_opt[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($ip_opt[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $ip_opt_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD IP Option Field">';
      echo '<BR>';
   } */

   echo '
   <TR><TD><B>Layer-4:</B>
       <TD>';

   $cs->criteria['layer4']->PrintForm();
   
echo '
   </TABLE>';

if ( $cs->criteria['layer4']->Get() == "TCP" )
{
  echo '
<!-- ************ TCP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="layer4title"><B>TCP Criteria</B></TD>
      <TD></TD>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';

      echo '<TR><TD><B>Port:</B>';
      echo '    <TD>';
      $cs->criteria['tcp_port']->PrintForm();

  echo '
  <TR>
      <TD VALIGN=TOP><B>Flags:</B>';
      $cs->criteria['tcp_flags']->PrintForm();

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
      $cs->criteria['tcp_field']->PrintForm();

/*      echo '<TR><TD><B>Option:</B>';
      echo '    <TD>';
  for ( $i = 0; $i < $tcp_opt_cnt; $i++ )
  {
      echo '    <SELECT NAME="tcp_opt['.$i.'][0]"><OPTION VALUE=" " '.chk_select($tcp_opt[$i][0]," ").'>__'; 
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_opt[$i][0],"(").'>(</SELECT>';
      echo '    <SELECT NAME="tcp_opt['.$i.'][1]"><OPTION VALUE=" "      '.chk_select($tcp_opt[$i][1]," ").'>{ field }';
      echo '                                       <OPTION VALUE="opt_code" '.chk_select($tcp_opt[$i][1],"opt_code").'>code';
      echo '                                       <OPTION VALUE="opt_len" '.chk_select($tcp_opt[$i][1],"opt_len").'>length</SELECT>';
      echo '    <SELECT NAME="tcp_opt['.$i.'][2]"><OPTION VALUE="="  '.chk_select($tcp_opt[$i][2],"="). '>=';
      echo '                                       <OPTION VALUE="!=" '.chk_select($tcp_opt[$i][2],"!=").'>!=';
      echo '                                       <OPTION VALUE="<"  '.chk_select($tcp_opt[$i][2],"<"). '><';
      echo '                                       <OPTION VALUE="<=" '.chk_select($tcp_opt[$i][2],"<=").'><=';
      echo '                                       <OPTION VALUE=">"  '.chk_select($tcp_opt[$i][2],">"). '>>';
      echo '                                       <OPTION VALUE=">=" '.chk_select($tcp_opt[$i][2],">=").'>>=</SELECT>';
      echo '    <INPUT TYPE="text" NAME="tcp_opt['.$i.'][3]" SIZE=5 VALUE="'.$tcp_opt[$i][3].'">';
      echo '    <SELECT NAME="tcp_opt['.$i.'][4]"><OPTION VALUE=" " '.chk_select($tcp_opt[$i][4]," ").'>__';
      echo '                                       <OPTION VALUE="(" '.chk_select($tcp_opt[$i][4],"(").'>(';
      echo '                                       <OPTION VALUE=")" '.chk_select($tcp_opt[$i][4],")").'>)</SELECT>';
      echo '    <SELECT NAME="tcp_opt['.$i.'][5]"><OPTION VALUE=" "   '.chk_select($tcp_opt[$i][5]," ").  '>__';
      echo '                                      <OPTION VALUE="OR" '.chk_select($tcp_opt[$i][5],"OR").  '>OR';
      echo '                                      <OPTION VALUE="AND" '.chk_select($tcp_opt[$i][5],"AND").'>AND</SELECT>';
      if ( $i == $tcp_opt_cnt-1 )
         echo '    <INPUT TYPE="submit" NAME="submit" VALUE="ADD TCP Option Field">';
      echo '<BR>';
   } */

  echo'
</TABLE>';
}

if ( $cs->criteria['layer4']->Get() == "UDP" )
{
  echo '
<!-- ************ UDP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="layer4title"><B>UDP Criteria</B></TD>
      <TD></TD>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';

      echo '<TR><TD><B>Port:</B>';
      echo '    <TD>';
      $cs->criteria['udp_port']->PrintForm();

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
      $cs->criteria['udp_field']->PrintForm();
  echo'
</TABLE>';
}


if ( $cs->criteria['layer4']->Get() == "ICMP" )
{
  echo  '
<!-- ************ ICMP Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="layer4title"><B>ICMP Criteria</B></TD>
      <TD></TD>
</TABLE>


<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">';

      echo '<TR><TD><B>Misc:</B>';
      echo '    <TD>';
      $cs->criteria['icmp_field']->PrintForm();
   echo '
</TABLE>'; 
}

echo '
<!-- ************ Payload Criteria ******************** -->
<P>
<TABLE WIDTH="100%" BORDER=0>
  <TR>
      <TD WIDTH="40%" CLASS="payloadtitle"><B><FONT COLOR="#FFFFFF">Payload Criteria</FONT></B></TD>
      <TD></TD></TR>
</TABLE>

<TABLE WIDTH="100%" BORDER=2 BGCOLOR="#CCCC99">
  <TR>
      <TD>';
      $cs->criteria['data']->PrintForm();

        echo '
</TABLE>';

  echo '<INPUT TYPE="hidden" NAME="new" VALUE="1">';
  echo '<P>
        <CENTER>
        <TABLE BORDER=1>
        <TR><TD>
            <FONT>
            <B>Sort order:</B>
            <INPUT TYPE="radio" NAME="sort_order" 
                   VALUE="none" '.chk_check($sort_order, "none").'> none |
            <INPUT TYPE="radio" NAME="sort_order" 
                   VALUE="time_a" '.chk_check($sort_order, "time_a").'> timestamp (ascend) |
            <INPUT TYPE="radio" NAME="sort_order" 
                   VALUE="time_d" '.chk_check($sort_order, "time_d").'> timestamp (descend) |
            <INPUT TYPE="radio" NAME="sort_order" 
                   VALUE="sig" '.chk_check($sort_order, "sig").'> signature <!--|
            <INPUT TYPE="radio" NAME="sort_order" 
                   VALUE="sip" '.chk_check($sort_order, "sip").'> source IP |
            <INPUT TYPE="radio" NAME="sort_order" 
                   VALUE="dip" '.chk_check($sort_order, "dip").'> dest. IP-->
            <BR>
            <CENTER><INPUT TYPE="submit" NAME="submit" VALUE="Query DB"></CENTER>
             </FONT>
             </TD>
        </TR>
        </TABLE>
        </CENTER>';
?>
